from sqlalchemy import Column, ForeignKey, Index, Integer
from sqlalchemy.orm import backref, relationship

from app.db.models import BaseModel, TableMixin
from app.db.role.model import Role
from app.db.user.model import User


class UserRole(BaseModel, TableMixin):
    __tablename__ = "user_role"
    user_role_id = Column(Integer, primary_key=True)
    user_id = Column(
        Integer,
        ForeignKey("user.user_id"),
        nullable=False,
        autoincrement=False,
    )
    role_id = Column(
        Integer,
        ForeignKey("role.role_id"),
        nullable=False,
        autoincrement=False,
    )

    role = relationship(
        Role, backref=backref("user_role", cascade="all, delete-orphan")
    )
    user = relationship(
        User,
        backref=backref("user_role", cascade="all, delete-orphan"),
        foreign_keys=[user_id],
        remote_side=[User.user_id],
    )

    __table_args__ = (
        Index(
            f"ix_{__tablename__}_unique_user_role_isactive",
            "user_id",
            "role_id",
            unique=True,
            postgresql_where="deleted = FALSE",
        ),
    )
