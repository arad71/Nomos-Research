from typing import List, Optional, Tuple

from loguru import logger
from pydantic import BaseModel

import app.db.taxon_name.calculated as calculated

from ..taxon_rank.enums import RankAbbreviationVals
from . import schema
from .infrageneric_name_definitions.infrageneric_name import (
    NameComponent,
    Source,
    SubGeneraNameDefinitions,
)
from .infrageneric_name_definitions.infrageneric_name_format_definitions import (
    PlacementType,
    all_name_combinations,
)


class InfraGenericNameModel(BaseModel):
    """
    Represents an infra-generic name model.

    This class holds the result of a single formatted name
    """

    id: int = 0
    formatted_name: str = ""
    name_version: str = ""
    author: Optional[str] = None
    formatted_name_with_author: Optional[str] = None
    contributing_taxon_names: List[str] = []
    contributing_taxon_name_ids: List[int] = []
    info: Optional[str] = None
    searched_taxon_id: int = None
    italicized_name: Optional[str] = None


class NameComponentModel(BaseModel):
    """
    Represents a name component model.

    This class holds an individual word during the name creation process.
    Storing the word that was selected, the id of the taxon entry that contained the
    word, and error information logged during the selection of the word.
    """

    name_value: str = ""
    source_name_value: Optional[str] = None
    taxon_name_id: Optional[int] = None
    info: Optional[str] = None


class NameComponentsListModel(BaseModel):
    """
    Represents a list of name components.

    This class holds a combination of definition and query information.
    When a word is identified as being a possible name component, the word information
    is stored here. The value, rank abbreviation, and taxon id are stored from the
    query, the word preference is stored from the definition.
    """

    value: Optional[str] = None
    rank_abbreviation: Optional[str] = None
    preference_tuple: Optional[Tuple[int, int]] = None
    taxon_name_id: Optional[int] = None


class DefinitionComponentsListModel(BaseModel):
    """
    Represents a list of definition components.

    This class holds a definition word option. The defined hierarchy rank and column
    label are used to select a word from the query data (i.e. Genus.uninomial) and the
    preference is used for later word option selection.
    """

    hierarchy_rank: Optional[str] = None
    column_label: Optional[str] = None
    use_searched_name: bool = False
    preference_tuple: Optional[Tuple[int, int]] = None


class InfraGenericNames:
    """
    Generates defined InfraGeneric names.

    This class uses pre-defined name definitions to generate a series of names from a
    single taxon id query where the full taxon hierarchy information is provided.
    """

    name_definitions = SubGeneraNameDefinitions(definitions_list=all_name_combinations)

    @classmethod
    def generate_names(
        cls, searched_taxon_id: int, taxon_info: List[schema.TaxonNameRow]
    ) -> List[InfraGenericNameModel]:
        """
        Generates infra-generic names based on the provided query results and the
        specified name format definitions.

        Args:
            searched_taxon_id (int): The ID of the searched taxon.
            taxon_info (List[dict]): Query result from the taxon_id entry

        Returns:
            List[InfraGenericNameModel]: The generated infra-generic names.
        """
        # start with an empty results list
        formatted_names = []

        searched_taxon_row: schema.TaxonNameRow = next(
            filter(lambda d: d.taxon_name_id == searched_taxon_id, taxon_info),
            None,
        )
        taxon_author = searched_taxon_row.author if searched_taxon_row else None

        # process each defined name included in the "all_names" list
        for definition in cls.name_definitions.definitions_list:
            # make sure the name components are processed in order
            name_definition_components_sorted = sorted(
                definition.name_components, key=lambda x: x.word_order_placement
            )

            # set generic new name attributes
            new_name = InfraGenericNameModel(
                id=definition.id,
                name_version=definition.name_version,
                searched_taxon_id=searched_taxon_id,
            )
            generated_name = ""
            italicized_name = ""
            # process all the individual components of the name to build it up
            for definition_component in name_definition_components_sorted:
                # Static words are set first
                if definition_component.static_string.is_static:
                    generated_name += definition_component.static_string.value + " "
                    italicized_name += definition_component.static_string.value + " "

                    # Move on to the next component if we just processed a static word
                    continue
                # Get all the possible options for the component word
                name_component_list = cls._get_name_components(
                    definition_component.source, taxon_info, searched_taxon_id
                )
                # Select one single word from all possible components
                name_component = cls._select_name_component(
                    definition_component, name_component_list
                )
                italicized_name_component = cls._select_name_component(
                    definition_component, name_component_list, italicize=True
                )
                # Handle errors in the component selection process
                # the info field should only be populated if there was a problem
                if name_component.info is not None:
                    new_name.info = (
                        f"{name_component.info}: Component number"
                        f" [{definition_component.word_order_placement}], Defined"
                        f" source options [{definition_component.sources_summary},"
                        f" Reference Taxon name ID [{name_component.taxon_name_id}]."
                    )
                    # erase the name progress, don't return names with problems
                    generated_name = ""
                    italicized_name = ""
                    break
                else:
                    # Optional components that don't exist won't have a contribution
                    if (
                        name_component.taxon_name_id
                        and name_component.source_name_value
                    ):
                        # record the taxon id that is contributing this word
                        new_name.contributing_taxon_names.append(
                            name_component.source_name_value
                        )
                        new_name.contributing_taxon_name_ids.append(
                            name_component.taxon_name_id
                        )
                        # update the in-progress name
                        generated_name = generated_name + name_component.name_value
                        italicized_name = (
                            italicized_name + italicized_name_component.name_value
                        )
            # remove any leading/trailing white space and add the formatted name
            new_name.formatted_name = generated_name.strip()
            new_name.italicized_name = italicized_name.strip()

            if taxon_author:
                new_name.author = taxon_author
                if searched_taxon_row.is_autonym:
                    placeholder = PlacementType.AUTONYM
                else:
                    placeholder = PlacementType.STANDARD
                cls.replace_placeholder_authors(new_name, placeholder, taxon_author)
            else:
                new_name.formatted_name_with_author = new_name.formatted_name
            cls.strip_placeholders(new_name)
            formatted_names.append(new_name)
        return formatted_names

    @classmethod
    def replace_placeholder_authors(
        cls,
        new_name: InfraGenericNameModel,
        placeholder: PlacementType,
        author: str,
    ):
        new_name.formatted_name_with_author = new_name.formatted_name.replace(
            placeholder.value, author
        )
        new_name.italicized_name = new_name.italicized_name.replace(
            placeholder.value, author
        )

    @classmethod
    def strip_placeholders(cls, new_name: InfraGenericNameModel):
        """
        Strips the placeholders from a string.

        This class method iterates through all placeholders in
        the PlacementType enumeration and removes them from the string.

        Args:
            new_name (str): The string from which to remove placeholders.

        Returns:
            None.

        Class Attributes:
            PlacementType: An enumeration of possible placeholders.

        Example:
            MyClass.strip_placeholders("Hello, {name}")

        Note: This method modifies the new_name input in-place, it does not return a
        new string.

        """
        for placeholder in PlacementType:
            cls.strip_placeholder(new_name, placeholder)

    @classmethod
    def strip_placeholder(cls, name: InfraGenericNameModel, placeholder: PlacementType):
        """
        Strips the predefined placeholder from the given fields in the name model
        object.

        This class method modifies the following fields of the InfraGenericNameModel
        instance: 'formatted_name', 'formatted_name_with_author', and 'italicized_name'.
        It checks each of these fields and if the placeholder string exists,
        it is removed from the field value.

        Args: name (InfraGenericNameModel): The model instance where placeholder
        needs to be removed. placeholder (PlacementType): The placeholder string that
        needs to be removed from the fields.

        Returns:
            None. This method modifies the 'name' object in-place.

        Example:
            ```python
            strip_placeholder(nameInstance, PlacementType('<placeholder>'))
            ```
        """
        for attr in ["formatted_name", "formatted_name_with_author", "italicized_name"]:
            value = name.__getattribute__(attr)
            name.__setattr__(attr, value.replace(f" {placeholder.value}", ""))

    @staticmethod
    def _get_name_components(
        component_sources: List[Source],
        taxon_info: List[schema.TaxonNameRow],
        searched_taxon_id: int,
    ) -> List[NameComponentsListModel]:
        """
        Gets the name components based on the component sources and taxon info.

        A name component is the row from the query result where the taxon rank name
        matches a rank name specified in the sources list. All matches are returned,
        match selection logic is performed elsewhere.

        Args:
            component_sources (List[Source]): The component sources
            taxon_info (List[dict]): Information about the taxon.
            searched_taxon_id: int

        Returns:
            List[NameComponentsListModel]: The name components.
        """
        # this section creates a flat list of preference sources from the definition
        # json. This is required because there could be multiple valid sources to choose
        # from, and each source could have multiple valid fields to choose from.
        # In order to keep track of the priority for each item, the two preferences are
        # treated as a major/minor preference indicator as a tuple. This way, preference
        # (1,7) will be chosen over preference (2,1) when selecting word preferences.
        definition_components_list = [
            DefinitionComponentsListModel(
                hierarchy_rank=source.hierarchy_rank,
                column_label=field.label,
                use_searched_name=source.use_searched_name,
                preference_tuple=(source.preference, field.preference),
            )
            for source in component_sources
            for field in source.field
        ]

        # This section creates a list of the word options that can be used for word
        # selection in later steps. If the definition specifies to use the searched
        # name and the name is the searched name and the taxon has a value for the
        # defined field, return that field. If the hierarchy rank was defined as a
        # valid option in the definition, and the hierarchy rank exists in the taxon
        # query data, and the field for that rank (uninomial, etc.) is populated,
        # then the information is saved to the list.
        name_components_list = [
            NameComponentsListModel(
                value=taxon.__getattribute__(definition.column_label),
                rank_abbreviation=taxon.rank_abbrev,
                preference_tuple=definition.preference_tuple,
                taxon_name_id=taxon.taxon_name_id,
            )
            for definition in definition_components_list
            for taxon in taxon_info
            if (
                (
                    definition.use_searched_name
                    and taxon.taxon_name_id == searched_taxon_id
                )
                or (
                    definition.hierarchy_rank is not None
                    and taxon.rank_name == definition.hierarchy_rank
                )
            )
            and taxon.__getattribute__(definition.column_label)
        ]

        return name_components_list

    @staticmethod
    def _select_name_component(
        definition_component: NameComponent,
        name_component_list: List[NameComponentsListModel],
        italicize: bool = False,
    ) -> NameComponentModel:
        """
        Selects the name component based on the definition component and component list.

        A single word component for the name is selected and modified as defined in the
        NameComponent attributes.

        Errors encountered during name selection are documented in the info attribute.

        Args:
            definition_component (NameComponent): The definition component
            name_component_list (List[NameComponentsListModel]): The name component list

        Returns:
            NameComponentModel: The selected name component.
        """
        name_component = NameComponentModel()

        # There might not be any possible options.
        # If the word is optional, return an empty string and keep going, else, abort.
        if not name_component_list:
            if definition_component.is_optional:
                name_component.name_value = ""
                return name_component
            else:
                name_component.info = "Mandatory name component does not exist"
                return name_component

        # recording what we're doing for error logging
        action = "Source sorting"
        try:
            # sort the list by major/minor preference and select the top entry
            name_component_source = sorted(
                name_component_list, key=lambda x: x.preference_tuple
            )[0]
            # record the taxon id selected for this component
            action = "Value setting"
            name_component.taxon_name_id = name_component_source.taxon_name_id

            # remove any leading or trailing white space
            action = "Name value string"
            name_component.source_name_value = name_component_source.value
            name_value = name_component_source.value.strip()
            if italicize:
                name_value = calculated.italicize_name(name_value)

            # handle the definition word manipulation settings
            if definition_component.name_is_abbreviated:
                action = "Name value abbreviation"
                name_value = name_value[0] + "."
            if definition_component.use_rank_abbreviation:
                action = "Rank abbreviation"
                # only a subset of kingdoms should have rank abbreviations defined
                # skip the rank abbreviation task if none exists in the query data
                if name_component_source.rank_abbreviation:
                    name_abbreviation = name_component_source.rank_abbreviation.strip()
                    rank_abbreviation = RankAbbreviationVals[name_abbreviation].strip()
                    name_value = rank_abbreviation + " " + name_value
            if definition_component.has_parentheses:
                action = "Parentheses"
                name_value = f"({name_value})"
            name_component.name_value = name_value + " "

        except Exception as e:
            # It's unlikely anything could happen, but this is the only place we
            # manipulate data that came from the query so this is a catch-all.
            name_component.info = (
                f"Unexpected Error [{e}] encountered with component [{action}]"
            )
            logger.error(
                f"Unexpected Error [{e}] encountered with component [{action}]"
            )

        return name_component
