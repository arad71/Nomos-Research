from typing import List, Optional, overload

from fastapi import APIRouter, Depends, Response

from app.api.dependencies.range_query import RangeQueryParameter
from app.core.auth import authorize, get_current_active_user
from app.db.cross_reference.crud import CrossReferenceCrud
from app.db.cross_reference.schema import (
    CrossReference,
    CrossReferenceCreate,
    CrossReferenceEdit,
)
from app.db.role.constants import Role
from app.db.session import get_db
from app.db.user.schema import User

cross_references_router = r = APIRouter(prefix="/cross_references")


@r.get(
    "",
    response_model=List[CrossReference],
    response_model_exclude_none=True,
    dependencies=[authorize()],
)
async def cross_reference_list(
    response: Response,
    range: Optional[str] = RangeQueryParameter,
    sort: Optional[str] = None,
    filter: Optional[str] = None,
    db=Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """
    Get all cross_references
    """
    cross_references, content_range = CrossReferenceCrud.get_items(
        db, current_user, range=range, sort=sort, list_filter=filter
    )
    # This is necessary for react-admin to work
    response.headers["Content-Range"] = content_range
    return cross_references


@r.get(
    "/{cross_reference_id}",
    response_model=CrossReference,
    response_model_exclude_none=True,
    dependencies=[authorize()],
)
async def cross_reference_details(
    cross_reference_id: int,
    db=Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """
    Get any cross_reference details
    """
    cross_reference = CrossReferenceCrud.get_item(db, current_user, cross_reference_id)
    return cross_reference


@r.post(
    "",
    response_model=CrossReference,
    response_model_exclude_none=True,
    dependencies=[
        authorize(
            scopes=[
                Role.MANAGER["name"],
                Role.OFFICER["name"],
                Role.SUPER_ADMIN["name"],
            ]
        )
    ],
)
async def cross_reference_create(
    cross_reference: CrossReferenceCreate,
    db=Depends(get_db),
    current_user=Depends(get_current_active_user),
):
    """
    Create a new cross_reference
    """
    return CrossReferenceCrud.create_item(db, cross_reference, current_user.user_id)


@r.put(
    "/{cross_reference_id}",
    response_model=CrossReference,
    response_model_exclude_none=True,
    dependencies=[
        authorize(
            scopes=[
                Role.MANAGER["name"],
                Role.OFFICER["name"],
                Role.SUPER_ADMIN["name"],
            ]
        )
    ],
)
async def cross_reference_edit(
    cross_reference_id: int,
    cross_reference: CrossReferenceEdit,
    db=Depends(get_db),
    current_user=Depends(get_current_active_user),
):
    """
    Update existing cross_reference
    """
    return CrossReferenceCrud.edit_item(
        db, current_user, cross_reference_id, cross_reference
    )


@overload
@r.delete(
    "/{cross_reference_id}",
    dependencies=[
        authorize(
            scopes=[
                Role.SUPER_ADMIN["name"],
                Role.MANAGER["name"],
            ]
        )
    ],
)
async def cross_reference_delete(
    cross_reference_id: int,
    db=Depends(get_db),
    current_user=Depends(get_current_active_user),
):
    """
    Delete existing cross_reference
    """
    return CrossReferenceCrud.delete_item(db, current_user, cross_reference_id)


@r.delete(
    "/{cross_reference_id}/hard",
    dependencies=[
        authorize(
            scopes=[
                Role.SUPER_ADMIN["name"],
            ]
        )
    ],
)
async def cross_reference_delete(
    cross_reference_id: int,
    db=Depends(get_db),
    current_user=Depends(get_current_active_user),
):
    """
    Delete existing cross_reference
    """
    return CrossReferenceCrud.delete_item(db, current_user, cross_reference_id, True)


@r.post(
    "/{cross_reference_id}/restore",
    response_model=CrossReference,
    response_model_exclude_none=True,
    dependencies=[
        authorize(
            scopes=[
                Role.SUPER_ADMIN["name"],
            ]
        )
    ],
)
async def cross_reference_restore(
    cross_reference_id: int,
    db=Depends(get_db),
    current_user=Depends(get_current_active_user),
):
    """
    Restore a soft deleted cross_reference
    """
    return CrossReferenceCrud.undelete_item(db, current_user, cross_reference_id)
